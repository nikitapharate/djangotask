# myapp/urls.py 
from django.urls import path
from .views import teachers, students

urlpatterns = [
    path('teachers/', teachers, name='teachers'),
    path('students/', students, name='students'),
]

# myapp/urls.py for level 2
from django.urls import path
from .views import teachers, students, generate_certificate

urlpatterns = [
    path('teachers/', teachers, name='teachers'),
    path('students/', students, name='students'),
    path('generate-certificate/', generate_certificate, name='generate_certificate'),
]


# myapp/urls.py for level 3
from django.urls import path
from .views import teachers, students, generate_certificate, verify_certificate

urlpatterns = [
    path('teachers/', teachers, name='teachers'),
    path('students/', students, name='students'),
    path('generate-certificate/', generate_certificate, name='generate_certificate'),
    path('verify-certificate/<str:token>/', verify_certificate, name='verify_certificate'),
]


