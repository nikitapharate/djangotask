# myapp/views.py
from django.shortcuts import render
from .models import Teacher, Student

def teachers(request):
    all_teachers = Teacher.objects.all()
    return render(request, 'teachers.html', {'teachers': all_teachers})

def students(request):
    all_students = Student.objects.all()
    return render(request, 'students.html', {'students': all_students})

# myapp/views.py for level 2
import jwt
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .models import Teacher, Student
from .forms import PairForm

def generate_certificate(request):
    if request.method == 'POST':
        form = PairForm(request.POST)
        if form.is_valid():
            teacher = form.cleaned_data['teacher']
            student = form.cleaned_data['student']

            # You can customize the certificate content as needed
            certificate_content = f"Certificate of Completion\n\nThis is to certify that {student.name} has completed a course under the guidance of {teacher.name}."

            # Generate JWT token with teacher and student information
            token = jwt.encode({'teacher_id': teacher.id, 'student_id': student.id}, 'your-secret-key', algorithm='HS256')

            # For now, let's just return the certificate and the token as a response
            response = HttpResponse(content_type='text/plain')
            response['Content-Disposition'] = 'attachment; filename="certificate.txt"'
            response.write(certificate_content + f"\n\nJWT Token: {token}")
            return response
    else:
        form = PairForm()

    return render(request, 'generate_certificate.html', {'form': form})

# myapp/views.py for level 3
import jwt
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .models import Teacher, Student
from .forms import PairForm

SECRET_KEY = 'your-secret-key'  # Replace with a secure secret key

def verify_certificate(request, token):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        teacher_id = payload['teacher_id']
        student_id = payload['student_id']

        teacher = get_object_or_404(Teacher, pk=teacher_id)
        student = get_object_or_404(Student, pk=student_id)

        return render(request, 'verify_certificate.html', {'teacher': teacher, 'student': student})
    except jwt.ExpiredSignatureError:
        return HttpResponse('Token has expired.', status=400)
    except jwt.InvalidTokenError:
        return HttpResponse('Invalid token.', status=400)


   