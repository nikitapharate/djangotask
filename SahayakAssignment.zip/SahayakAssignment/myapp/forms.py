# myapp/forms.py for level 2
from django import forms

class PairForm(forms.Form):
    teacher = forms.ModelChoiceField(queryset=Teacher.objects.all())
    student = forms.ModelChoiceField(queryset=Student.objects.all())

